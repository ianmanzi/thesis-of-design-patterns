import java.util.*;

// ================================================================
// Flyweight intrinsic state for DataPoint
// ================================================================
class DataPointIntrinsicState {
    private final String timestamp;
    private final String dataType;

    public DataPointIntrinsicState(String timestamp, String dataType) {
        this.timestamp = timestamp;
        this.dataType = dataType;
    }

    public String getTimestamp() { return timestamp; }
    public String getDataType() { return dataType; }
}

// ================================================================
// Flyweight factory
// ================================================================
class DataPointFactory {
    private static final Map<String, DataPointIntrinsicState> states = new HashMap<>();

    public static DataPointIntrinsicState getIntrinsicState(String timestamp, String dataType) {
        String key = timestamp + "_" + dataType;
        return states.computeIfAbsent(key, k -> new DataPointIntrinsicState(timestamp, dataType));
    }
}

// ================================================================
// DataPoint optimized with Flyweight
// ================================================================
class DataPointOptimized {
    private final double value;
    private final DataPointIntrinsicState intrinsicState;

    public DataPointOptimized(double value, String timestamp, String dataType) {
        this.value = value;
        this.intrinsicState = DataPointFactory.getIntrinsicState(timestamp, dataType);
    }

    public double getValue() { return value; }
    public String getTimestamp() { return intrinsicState.getTimestamp(); }
    public String getDataType() { return intrinsicState.getDataType(); }
}

// ================================================================
// Singleton Database Connection Pool
// ================================================================
class DatabaseConnection {
    private static int counter = 0;
    private int id;
    public DatabaseConnection() { id = ++counter; }
    public int getId() { return id; }
}

class DatabaseConnectionPool {
    private static DatabaseConnectionPool instance;
    private List<DatabaseConnection> connections = new ArrayList<>();

    private DatabaseConnectionPool() {
        // create a few pooled connections
        for (int i = 0; i < 2; i++) {
            connections.add(new DatabaseConnection());
        }
        System.out.println("Database pool created with " + connections.size() + " connections.");
    }

    public static synchronized DatabaseConnectionPool getInstance() {
        if (instance == null) instance = new DatabaseConnectionPool();
        return instance;
    }

    public DatabaseConnection getConnection() {
        // Simple round-robin reuse
        DatabaseConnection conn = connections.remove(0);
        connections.add(conn);
        System.out.println("Using DB connection ID: " + conn.getId());
        return conn;
    }
}

// ================================================================
// Analytics Processor with actual working logic
// ================================================================
class AnalyticsProcessor {
    private List<DataPointOptimized> dataPoints = new ArrayList<>();

    public void addData(double value, String timestamp, String dataType) {
        DataPointOptimized point = new DataPointOptimized(value, timestamp, dataType);
        dataPoints.add(point);
    }

    public void generateReport() {
        System.out.println("\n--- Analytics Report ---");
        Map<String, List<DataPointOptimized>> grouped = new HashMap<>();
        for (DataPointOptimized dp : dataPoints) {
            grouped.computeIfAbsent(dp.getDataType(), k -> new ArrayList<>()).add(dp);
        }
        for (String type : grouped.keySet()) {
            List<DataPointOptimized> list = grouped.get(type);
            double sum = 0;
            for (DataPointOptimized dp : list) sum += dp.getValue();
            double avg = sum / list.size();
            System.out.println("DataType: " + type + ", Count=" + list.size() + ", Sum=" + sum + ", Avg=" + avg);
        }
    }
}

// ================================================================
// Demo with working logic
// ================================================================
public class AnalyticsDemo {
    public static void main(String[] args) {
        // Singleton DB pool
        DatabaseConnectionPool pool = DatabaseConnectionPool.getInstance();
        DatabaseConnection conn1 = pool.getConnection();
        DatabaseConnection conn2 = pool.getConnection();

        // Analytics processor
        AnalyticsProcessor processor = new AnalyticsProcessor();

        // Add actual data points
        processor.addData(100, "2025-08-24 10:00:00", "sales");
        processor.addData(200, "2025-08-24 10:00:00", "sales"); // same timestamp, same type -> reused intrinsic
        processor.addData(50, "2025-08-24 11:00:00", "expenses");
        processor.addData(80, "2025-08-24 11:00:00", "expenses");
        processor.addData(300, "2025-08-24 12:00:00", "sales");

        // Generate actual report (sum and average)
        processor.generateReport();
    }
}
