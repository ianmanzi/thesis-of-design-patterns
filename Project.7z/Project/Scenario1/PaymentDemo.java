import java.util.*;

// ================================================================
// Figure 1.1: Before using Strategy pattern
// Monolithic PaymentGateway
// ================================================================
class Account {
    private String id;
    private double balance;

    public Account(String id, double balance) {
        this.id = id;
        this.balance = balance;
    }

    public String getId() { return id; }
    public double getBalance() { return balance; }

    public boolean deduct(double amount) {
        if (amount <= balance) {
            balance -= amount;
            return true;
        } else {
            return false;
        }
    }
}

class PaymentGatewayBefore {
    public void processPayment(String method, Account account, double amount) {
        if (method.equals("CreditCard")) {
            if (account.deduct(amount)) {
                System.out.println("CreditCard payment of $" + amount + " successful for account " + account.getId());
            } else {
                System.out.println("CreditCard payment failed: insufficient funds in account " + account.getId());
            }
        } else if (method.equals("PayPal")) {
            if (account.deduct(amount)) {
                System.out.println("PayPal payment of $" + amount + " successful for account " + account.getId());
            } else {
                System.out.println("PayPal payment failed: insufficient funds in account " + account.getId());
            }
        } else if (method.equals("Crypto")) {
            if (account.deduct(amount)) {
                System.out.println("Crypto payment of $" + amount + " successful for account " + account.getId());
            } else {
                System.out.println("Crypto payment failed: insufficient funds in account " + account.getId());
            }
        }
    }
}

// ================================================================
// Figure 1.2: Strategy pattern implementation
// ================================================================
interface PaymentStrategy {
    boolean pay(Account account, double amount);
}

class CreditCardPayment implements PaymentStrategy {
    private String cardNumber;

    public CreditCardPayment(String cardNumber) { this.cardNumber = cardNumber; }

    @Override
    public boolean pay(Account account, double amount) {
        System.out.println("Validating credit card: " + cardNumber);
        if (account.deduct(amount)) {
            System.out.println("Charging credit card: $" + amount + " for account " + account.getId());
            System.out.println("Credit card payment successful!");
            return true;
        } else {
            System.out.println("Credit card payment failed: insufficient funds!");
            return false;
        }
    }
}

class PayPalPayment implements PaymentStrategy {
    private String email;

    public PayPalPayment(String email) { this.email = email; }

    @Override
    public boolean pay(Account account, double amount) {
        System.out.println("Connecting to PayPal account: " + email);
        if (account.deduct(amount)) {
            System.out.println("Charging PayPal account: $" + amount + " for account " + account.getId());
            System.out.println("PayPal payment successful!");
            return true;
        } else {
            System.out.println("PayPal payment failed: insufficient funds!");
            return false;
        }
    }
}

class CryptoPayment implements PaymentStrategy {
    private String walletAddress;

    public CryptoPayment(String walletAddress) { this.walletAddress = walletAddress; }

    @Override
    public boolean pay(Account account, double amount) {
        System.out.println("Checking crypto wallet: " + walletAddress);
        if (account.deduct(amount)) {
            System.out.println("Transferring crypto: $" + amount + " for account " + account.getId());
            System.out.println("Crypto payment successful!");
            return true;
        } else {
            System.out.println("Crypto payment failed: insufficient funds!");
            return false;
        }
    }
}

class PaymentGatewayAfter {
    private PaymentStrategy strategy;

    public PaymentGatewayAfter(PaymentStrategy strategy) { this.strategy = strategy; }

    public void setStrategy(PaymentStrategy strategy) { this.strategy = strategy; }

    public void processPayment(Account account, double amount) {
        strategy.pay(account, amount);
    }
}

// ================================================================
// Figure 1.3: Demo comparing Before vs After
// ================================================================
public class PaymentDemo {
    public static void main(String[] args) {
        System.out.println("=== BEFORE: Monolithic PaymentGateway ===");
        Account acc1 = new Account("A1001", 500);
        PaymentGatewayBefore oldGateway = new PaymentGatewayBefore();
        oldGateway.processPayment("CreditCard", acc1, 100);
        oldGateway.processPayment("PayPal", acc1, 200);
        oldGateway.processPayment("Crypto", acc1, 300);

        System.out.println("\n=== AFTER: Strategy Pattern PaymentGateway ===");
        Account acc2 = new Account("A2002", 500);
        PaymentGatewayAfter gateway = new PaymentGatewayAfter(new CreditCardPayment("1234-5678-9012-3456"));
        gateway.processPayment(acc2, 100);

        System.out.println("------ Switching strategy ------");
        gateway.setStrategy(new PayPalPayment("user@example.com"));
        gateway.processPayment(acc2, 200);

        System.out.println("------ Switching strategy ------");
        gateway.setStrategy(new CryptoPayment("0xABCD1234EF567890"));
        gateway.processPayment(acc2, 50);

        System.out.println("\nRemaining balance in account " + acc2.getId() + ": $" + acc2.getBalance());
    }
}
