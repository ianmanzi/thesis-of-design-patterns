import java.util.*;

// ================================================================
// Figure 2.1: Notification System BEFORE Observer & Command
// ================================================================
class LegacyNotificationManager {
    private Map<String, List<String>> delivered = new HashMap<>();

    // Problem: All notification types are handled in one method
    public void sendNotification(String type, String recipient, String message) {
        delivered.computeIfAbsent(recipient, k -> new ArrayList<>()).add(type + ": " + message);
        System.out.println("Delivered " + type + " to " + recipient);
    }

    public Map<String, List<String>> getDelivered() { return delivered; }
}

class ApplicationClientBefore {
    public static void runBeforeScenario() {
        System.out.println("=== BEFORE: Legacy Notification System ===");
        LegacyNotificationManager manager = new LegacyNotificationManager();

        manager.sendNotification("email", "user@example.com", "Your order has shipped!");
        manager.sendNotification("push", "device-token-12345", "Special offer just for you.");
        manager.sendNotification("sms", "123-456-7890", "Reminder: Your appointment is tomorrow.");

        System.out.println("Delivered notifications: " + manager.getDelivered());
    }
}

// ================================================================
// Figure 2.2: Notification System AFTER Observer & Command patterns
// ================================================================

// Notification object
class Notification {
    private String recipient;
    private String message;

    public Notification(String recipient, String message) {
        this.recipient = recipient;
        this.message = message;
    }

    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }
}

// Observer Pattern
interface NotificationObserver {
    void update(Notification notification);
    Map<String, List<String>> getInbox();  // Store received notifications
}

// Concrete Observers
class EmailSender implements NotificationObserver {
    private Map<String, List<String>> inbox = new HashMap<>();

    @Override
    public void update(Notification notification) {
        inbox.computeIfAbsent(notification.getRecipient(), k -> new ArrayList<>())
             .add("EMAIL: " + notification.getMessage());
    }

    @Override
    public Map<String, List<String>> getInbox() { return inbox; }
}

class SMSSender implements NotificationObserver {
    private Map<String, List<String>> inbox = new HashMap<>();

    @Override
    public void update(Notification notification) {
        inbox.computeIfAbsent(notification.getRecipient(), k -> new ArrayList<>())
             .add("SMS: " + notification.getMessage());
    }

    @Override
    public Map<String, List<String>> getInbox() { return inbox; }
}

class PushSender implements NotificationObserver {
    private Map<String, List<String>> inbox = new HashMap<>();

    @Override
    public void update(Notification notification) {
        inbox.computeIfAbsent(notification.getRecipient(), k -> new ArrayList<>())
             .add("PUSH: " + notification.getMessage());
    }

    @Override
    public Map<String, List<String>> getInbox() { return inbox; }
}

// Subject
class NotificationService {
    private List<NotificationObserver> observers = new ArrayList<>();

    public void addObserver(NotificationObserver observer) {
        observers.add(observer);
    }

    public List<NotificationObserver> getObservers() { return observers; }
}

// Command Pattern
interface Command {
    void execute();
}

class SendNotificationCommand implements Command {
    private Notification notification;
    private NotificationObserver sender;

    public SendNotificationCommand(Notification notification, NotificationObserver sender) {
        this.notification = notification;
        this.sender = sender;
    }

    @Override
    public void execute() {
        sender.update(notification);
    }
}

// Command queue
class CommandQueue {
    private Queue<Command> queue = new LinkedList<>();

    public void add(Command command) { queue.add(command); }

    public void processAll() {
        while (!queue.isEmpty()) {
            queue.poll().execute();
        }
    }
}

// ================================================================
// Figure 2.3: Demo comparing BEFORE vs AFTER
// ================================================================
public class NotificationDemo {
    public static void main(String[] args) {
        // --- BEFORE scenario ---
        ApplicationClientBefore.runBeforeScenario();

        System.out.println("\n=== AFTER: Observer & Command Notification System ===");

        // --- AFTER scenario ---
        NotificationService service = new NotificationService();
        EmailSender email = new EmailSender();
        SMSSender sms = new SMSSender();
        PushSender push = new PushSender();

        service.addObserver(email);
        service.addObserver(sms);
        service.addObserver(push);

        // Create notifications
        Notification notification1 = new Notification("user@example.com", "System update available!");
        Notification notification2 = new Notification("123-456-7890", "Your appointment is tomorrow!");

        // Command queue
        CommandQueue queue = new CommandQueue();
        for (NotificationObserver sender : service.getObservers()) {
            queue.add(new SendNotificationCommand(notification1, sender));
            queue.add(new SendNotificationCommand(notification2, sender));
        }

        // Process all commands
        queue.processAll();

        // Display actual delivered notifications
        System.out.println("\nEmail inbox: " + email.getInbox());
        System.out.println("SMS inbox: " + sms.getInbox());
        System.out.println("Push inbox: " + push.getInbox());
    }
}
